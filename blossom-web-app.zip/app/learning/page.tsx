import LearningHub from "@/components/learning-hub"

export default function LearningPage() {
  return <LearningHub />
}
