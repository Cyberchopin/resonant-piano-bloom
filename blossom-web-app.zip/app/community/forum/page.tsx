import CommunityForum from "@/components/community-forum"

export default function ForumPage() {
  return <CommunityForum />
}
