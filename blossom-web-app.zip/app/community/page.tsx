import CommunityConnect from "@/components/community-connect"

export default function CommunityPage() {
  return <CommunityConnect />
}
