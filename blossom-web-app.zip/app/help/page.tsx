import HelpCenter from "@/components/help-center"

export default function HelpPage() {
  return <HelpCenter />
}
